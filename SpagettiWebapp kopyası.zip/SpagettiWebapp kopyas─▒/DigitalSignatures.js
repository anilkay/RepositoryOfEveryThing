/**
 * Created by anilkaynar on 9.12.2017.
 */
var crypto=require("crypto");
var signum=new Object();
var keypair=require("keypair");
/*
var sign = crypto.createSign('RSA-SHA256');

var pair = keypair(); //Create Public and Private key
console.log(pair);
sign.update("Anil Kaynar");
const privateKey ="-----BEGIN RSA PRIVATE KEY-----\n"+
    'MIIBOQIBAAJAVY6quuzCwyOWzymJ7C4zXjeV/232wt2ZgJZ1kHzjI73wnhQ3WQcL\n'+
    'DFCSoi2lPUW8/zspk0qWvPdtp6Jg5Lu7hwIDAQABAkBEws9mQahZ6r1mq2zEm3D/\n'+
    'VM9BpV//xtd6p/G+eRCYBT2qshGx42ucdgZCYJptFoW+HEx/jtzWe74yK6jGIkWJ\n'+
    'AiEAoNAMsPqwWwTyjDZCo9iKvfIQvd3MWnmtFmjiHoPtjx0CIQCIMypAEEkZuQUi\n'+
    'pMoreJrOlLJWdc0bfhzNAJjxsTv/8wIgQG0ZqI3GubBxu9rBOAM5EoA4VNjXVigJ\n'+
    'QEEk1jTkp8ECIQCHhsoq90mWM/p9L5cQzLDWkTYoPI49Ji+Iemi2T5MRqwIgQl07\n'+
    'Es+KCn25OKXR/FJ5fu6A6A+MptABL3r8SEjlpLc=\n'+
    '-----END RSA PRIVATE KEY-----';
console.log(sign.sign(privateKey, 'hex'));
 */
//2cfa8d317216fa4a553f25598e6355a12ecc734e0bf959c75614a44026a3d6e91794e7e54e5d2175294fbb09fb9718f921b61681628054135446522428bc0bee
//Encryption is work but 2 problem 1-how to create Rsa Private key
//2- This thing is little slow
/*
 const crypto = require('crypto');
 const verify = crypto.createVerify('SHA256');

 verify.write('some data to sign');
 verify.end();

 const publicKey = getPublicKeySomehow();
 const signature = getSignatureToVerify();
 console.log(verify.verify(publicKey, signature));
 // Prints: true or false
 */
signum.createPair=function create_keypair(callback) {
    callback(keypair());
}
signum.verify=function verify(publickey,signedtext,callback){
    const verify = crypto.createVerify('RSA-SHA256');
     return verify.verify(publickey,signedtext);
}
signum.sign=function (privateKey,text,callback) {
    const sign2 = crypto.createSign('RSA-SHA256');
    sign2.write('some data to sign');
    sign2.end();
 callback(sign.sign(privateKey, 'hex'));
}
module.exports=signum;