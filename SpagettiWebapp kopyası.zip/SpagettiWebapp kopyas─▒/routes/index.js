var express = require('express');
var router = express.Router();
var db=require("../db.js");
var mailmodule=require("../emailmodule");
var multer=require("multer");
var aws=require("aws-sdk");
var s3 = require( 'multer-storage-s3' );
var path=require("path");
aws.config.loadFromPath('./credit.json');
var signature=require("../DigitalSignatures");
var storage = s3({
    destination : function( req, file, cb ) {

        cb( null, 'upload/ilanid' );

    },
    filename    : function( req, file, cb ) {

        cb( null, file.fieldname + '-' + Date.now()+path.extname(file.originalname));
    },
    bucket      : 's3bucketname',
    region      : 'region'
});
var upload = multer({storage:storage});

/* GET home page. */
router.get('/', function(req, res, next) {
 // console.log(req.session);
  //console.log("User: "+req.session.user);
  //console.log("Sen ne demek istiyorsun "+req.session.id);
  res.render('Anasayfa', { title: 'Express' });
});
router.all('/ilanlar/:param',(req,res)=>{
        res.render(req.params.param);
    });
router.all('/iletisim/:param',(req,res)=>{
        res.render(req.params.param);
    });
router.post('/get/konutlar',(req,res)=>{
        var konutlar = []
           for(var i=0;i<15;i++){
               konutlar.push({ad:'konut',fiyat:'1500',parabirimi:'tl',metrekare:'85'});
            }
       for(var i=0;i<15;i++){
                konutlar.push({ad:'konut',fiyat:'2500',parabirimi:'tl',metrekare:'100'});
           }
       res.send({status:true,data:konutlar});
    });

router.post('/get/konut',(req,res)=>{
       var konutid = req.query.konutid;
                   res.render('konutpage',{data:konut})
               });
router.post('/get/arsalar',(req,res)=>{
       var arsalar = []
            for(var i=0;i<15;i++){
                arsalar.push({ad:'arsa',fiyat:'1500',parabirimi:'tl',metrekare:'85'});
            }
       for(var i=0;i<15;i++){
               arsalar.push({ad:'arsa',fiyat:'2500',parabirimi:'tl',metrekare:'100'});
            }
        res.send({status:true,data:arsalar});
    });
router.post('/get/arsa',(req,res)=> {
    var arsaid = req.query.arsaid
   // var query = "select * from arsalar where arsaid='" + arsaid + "'"
     //Db yazılcak
        res.render('arsapage', {data: {bir:"iki"}});
});
router.get("/deneme",function (req,res) {
  console.log(__dirname);
    console.log("Sen ne demek istiyorsun "+req.session.id);
    if(1==1) {
      //req.session.user = {name: "Anil Kaynar", mail: "aanilkay@gmail.com"};
        req.session.user="anilkay";
        req.session.mail="a@b.com";
      res.send("<h3>Bir takım diğer işler </h3>");
  }
   //res.render("error",{});
});

router.post('/get/devremulkler',(req,res)=>{
    var devremulkler = []
         for(var i=0;i<15;i++){
         devremulkler.push({ad:'devremulk',fiyat:'1500',parabirimi:'tl',metrekare:'85'});
         }
     for(var i=0;i<15;i++){
         devremulkler.push({ad:'devremulk',fiyat:'2500',parabirimi:'tl',metrekare:'100'});
         }
     res.send({status:true,data:devremulkler});
    });
router.get("/deneme2",function (req,res) {
   res.sendfile("/Users/anilkaynar/WebstormProject/EmlakBitirme"+"/index.htm");
});
router.post('/get/isyerleri',(req,res)=>{
     var isyerleri = []
         for(var i=0;i<15;i++){
         isyerleri.push({ad:'isyeri',fiyat:'1500',parabirimi:'tl',metrekare:'85'});
         }
     for(var i=0;i<15;i++){
         isyerleri.push({ad:'isyeri',fiyat:'2500',parabirimi:'tl',metrekare:'100'});
         }
     res.send({status:true,data:isyerleri});
    });

router.post('/get/isyer',(req,res)=>{
     var isyeriid = req.query.isyeriid;
     //Veritabanı yazılacak
             res.render('isyeripage',{data:konut})
             });

router.post('/get/devremulk',(req,res)=>{
    var devremulkid = req.query.devremulkid
      //  var query = "select * from devremulkler where devremulkid='"+devremulkid+"'"
      //Veritabanı yazılacak
            res.render('devremulkpage',{data:{bir:"iki"}});
        });
router.post("/uyeol",function (req,res) {
    let status=false;
    console.log("User: "+JSON.stringify(req.body));
    console.log(req.body.user);
   res.send({baska:"abc",username:req.body.user,status:status});
});
router.get("/uyedeneme",function (req,res) {
    res.render("uyegiris",{});

});
router.post("/register",function (req,res) {
   console.log("Register body",req.body);

   if(req.body.password===req.body.confirmPassword){
       db.addUser(req.body);
       mailmodule.yolla(req.body.email);
       res.send("<h1>Kolayca eklendi</h1>");
   }
   else {
       res.send("<h3>Eşleşmiyor kardeşim</h3>");
   }
});
router.get("/ilan",function (req,res) {
    res.render("ilan");
    //Parametre eklenecek
});
router.get("/dbekle",function (req,res) {
    db.ekle();
    res.send("Ekleme işlemi yapıldı"); //index.js ile ekleme işlemi yapıldı.
});
router.get("/iland:id",function (req,res) {
db.goster(req.params.id,function (error,result) {
    //console.log(result);
    //console.log(error);
    if(error!=undefined){
        res.send("<h1>Aradığınız ilana ulaşılamadı</h1>");
    }
    else if(result)
    res.render('ilangercek',result);
    else {
        res.send("<h1>Aradığınız ilana ulaşılamadı</h1>");
    }
});
});
router.get('/activation:email',function (req,res) {
   res.send("Aktivayson işlemi başarı ile sonuçlandı");
   pgd.aktivasyon(req.params.email,function (trut) {
       if(trut){
           res.send("Aktivayson işlemi başarı ile sonuçlandı");
       }
       else {
           res.send("Aktive edemedik kardeş");
       }
   })
});
router.get('/login',function (req,res) {
    res.render('Login');
});
router.post("/login",function (req,res) {
   const user=req.body.uname;
    const password=req.body.password;
    db.loginuser(user,password,function (err,result) {
        if(err){
            console.log(err);
            res.send("Login Başarız oldu");
        }
        else {
            console.log(result);
            req.session.user=result.kadi;
            req.session.email=result.email;
            res.send("Login işlemi başarı ile gerçeklendi "+result.kadi+" "+result.email);
        }
    })
});

router.get("/uploaddene",function (req,res,next) {
   res.render("uploaaddene",{});
});
router.post("/dummyupload",upload.single("image"),function (req,res,next) {
    console.log(upload); //This upload thing is work well in localhost
   console.log(req.files);
   console.log(req.file);
   res.send("<h1>Upload edildi </h1>");
});
router.get('/createprimarykey',function (req,res) {
    signature.createPair(function (obje) {
        res.send(obje); //Work fine but too slow
    })
});
module.exports = router;
//arn:aws:s3:::emlakbitirmeanil
//AKIAIJV2CMRVMRQFV76Q K1CdS+si/cORCkY7Ricd14yVaKzHxP4L8Y+6qopD Hide
//Eklemeler yapılmalı.
/*
 ALTER TABLE Siteuser
 ALTER COLUMN password  TYPE text;
 */
//insert into notla (metin,hash) values
//Create Table publicKeyTable (id serial primary key,userid bigint references siteuser(id),publickey text);
