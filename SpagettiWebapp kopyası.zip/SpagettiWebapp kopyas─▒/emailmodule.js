/**
 * Created by anilkaynar on 23.11.2017.
 */
const nodemailer = require("nodemailer");
var mailat = new Object();
var message = {
    from: 'your-mail@gmail.com',
    subject: 'Hesap Aktivasyonu',
    text: 'Merhabalar, Üye........',
    html: '<a src="> burada ülker link olacak'
};
var transporter = nodemailer.createTransport('smtps://mailadresi%40gmail.com:sifre@smtp.gmail.com');
mailat.yolla = function (email) {
    message.to = email;
    message.html = '<a src="emlakbitirme.herokuapp.com/aktivasyon' + email + ">";
    transporter.sendMail({
        from: 'onlineemlakis@gmail.com'
        , subject: 'Hesap Aktivasyonu',
        html: '<a src="> burada ülker link olacak',
        to: email,
       text: 'emlakbitirme.herokuapp.com/aktivasyon'+email
    }, function (error, info) {
        if (error) {
            return console.log(error);
        }
        console.log('Message sent: ' + info.response);
    });
}
//Yolla is working just fine
module.exports = mailat
