/**
 * Created by anilkaynar on 14.11.2017.
 */
//arn:aws:rds:us-west-2:462569725094:db:emlakdb
//emlakdb.cl3xq1l6yvil.us-west-2.rds.amazonaws.com
//username:anilkay
//db JTGN5KVBX5BVPM4AIPEUJKSOEM
//Hallederim
const pgpf = require('pg-promise')();
const crypto=require("crypto");
pgpf.pg.defaults.ssl = true;
var cn = {
    host: 'database-link', // server name or IP address;
    port: 5432,  //emlakdb.cl3xq1l6yvil.us-west-2.rds.amazonaws.com
    database: 'database',
    user: 'user',
    password: 'password'
};
var db8=pgpf(cn);
//var pgd=require("pg");
var pgd=new Object();
/* GET users listing. */
//pgd.connect("postgres://znnmwwhhpngwdq:6cd2f0319d3956b3cd7c9a8e1b0930f601596445903d7426709af8c27dbdf8c8@ec2-79-125-125-97.eu-west-1.compute.amazonaws.com:5432/dactt99nggtkt0"
//  , function(err, client) {
//    if (err) throw err;
//  console.log('Connected to postgres! Getting schemas...');
// cli=client;
//pgd.cli2=client;
// });
console.log(pgd);
db8.any("Select * from Bir",function (err,data) {
    if(err){
        console.log(err);
    }
    else {
        console.log(data);
    }
});
pgd.ekle=function(){
    db8.none("Insert into Bir Values(7,'Object olarak ne olacak bakalım')");
}//Work is a nice as other thing
pgd.goster=function (id,callback) {
  db8.one("Select * from ilan where id="+id).then(function(result){
      // console.log(result);
       callback(undefined,result);
    })
      .catch(function(error){
      console.log(error);
      callback(error,{});
    });
};
pgd.addUser=function (bilgi) {
    const hash = crypto.createHash('sha256');
    db8.none("Insert into Siteuser (adsoyad,kadi,email,password)values($1,$2,$3,$4)",[bilgi.isim,bilgi.kadi,bilgi.email,hash.update(bilgi.password).digest()])
        .then(function () {
          //  console.log("Basarili bir sekilde eklendi");
        })
        .catch(function (error) {
            console.log(error);
        });
}
pgd.aktivasyon=function (email,callback) {
    db8.none("Update siteuser set activation=true where email="+"'"+email+"'").then(function () {
      //  console.log("basarili bir sekilde aktive edildi");
        callback(true);
    }).catch(function (error) {
       console.log(error);
       callback(false);
    });
}
pgd.loginuser2=function (username,password,callback) {
    const hash = crypto.createHash('sha256');
    db8.one("Select * from siteuser where kadi="+"'"+username+"'"+" AND password="+"'"+hash.update(password).digest()+"'")
      .then(function (result) {
          callback(undefined,result);
      }).catch(function (err) {
        callback(err,undefined);
  })
};
pgd.loginuser=function (username,password,callback) {
    const hash = crypto.createHash('sha256');
    db8.one("Select * from siteuser where kadi=$1 ANd password=$2",[username,hash.update(password).digest()])
        .then(function (result) {
            callback(undefined,result);
        }).catch(function (err) {
        callback(err,undefined);
    })
};
module.exports=pgd;
//insert into notla (metin,hash) values
