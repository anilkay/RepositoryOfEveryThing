$(document).ready(function(){
    $.post('/get/iletisim',{},function(response){

        })
    })
