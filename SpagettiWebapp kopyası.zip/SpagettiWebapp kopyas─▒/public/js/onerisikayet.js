$(document).ready(function(){
    $.post('/get/onerisikayet',{},function(response){

    })
})