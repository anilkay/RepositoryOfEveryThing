$(document).ready(function(){
    $.post('/get/sozlesme',{},function(response){

    })
})