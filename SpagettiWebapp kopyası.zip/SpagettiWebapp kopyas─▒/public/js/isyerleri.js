$(document).ready(function(){
    $.post('/get/isyerleri',{},function(response){
        var isyerleri = response.data;
        $('#isyerleri').html('');
        isyerleri.forEach(function(isyeri){
            console.log(isyeri);
            var template =  '<div class="col-3">'+
                ' <div class="card mb-2">'+
                '   <img class="card-img-top" src="https://bulma.io/images/placeholders/128x128.png",style="height:150px;">'+
                '   <div class="card-body">'+
                '     <h4 class="card-title"> isyeri</h4>'+
                '     <p class="card-text"> 3+1 Daire (Manzaralı)</p>'+
                '     <ul class="list-group list-group-flush">'+
                '       <li class="list-group-item">'+isyeri.metrekare+' M2</li>'+
                '       <li class="list-group-item">'+isyeri.fiyat+'</li>'+
                '     </ul>'+
                '     <a class="btn btn-primary mt-2" href="/get/isyeri/?isyeriid='+isyeri.id+'"> İlana Git</a>'+
                '   </div>'+
                ' </div>'
            '</div>'
            $('#isyerleri').append(template);
        })
    })
})