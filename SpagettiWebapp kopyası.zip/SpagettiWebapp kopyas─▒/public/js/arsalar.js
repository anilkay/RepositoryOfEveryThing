$(document).ready(function(){
    $.post('/get/arsalar',{},function(response){
        var arsalar = response.data;
        $('#arsalar').html('');
        arsalar.forEach(function(arsa){
            console.log(arsa);
            var template =  '<div class="col-3">'+
                ' <div class="card mb-2">'+
                '   <img class="card-img-top" src="https://bulma.io/images/placeholders/128x128.png",style="height:150px;">'+
                '   <div class="card-body">'+
                '     <h4 class="card-title"> arsa</h4>'+
                '     <p class="card-text"> 3+1 Daire (Manzaralı)</p>'+
                '     <ul class="list-group list-group-flush">'+
                '       <li class="list-group-item">'+arsa.metrekare+' M2</li>'+
                '       <li class="list-group-item">'+arsa.fiyat+'</li>'+
                '     </ul>'+
                '     <a class="btn btn-primary mt-2" href="/get/arsa/?arsaid='+arsa.id+'"> İlana Git</a>'+
                '   </div>'+
                ' </div>'
            '</div>'
            $('#arsalar').append(template);
        })
    })
})